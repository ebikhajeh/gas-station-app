import { create } from "zustand";
import { storage } from "../persist/storage";
import { STORAGE_KEYS } from "../persist/storageKeys";

export type TabKey = "endOfDay" | "prepaid" | "propane";

type UiState = {
  selectedDate: string; // "YYYY-MM-DD"
  activeTab: TabKey;

  setSelectedDate: (date: string) => void;
  setActiveTab: (tab: TabKey) => void;
};

const today = () => new Date().toISOString().slice(0, 10);

type PersistedUiState = Pick<UiState, "selectedDate" | "activeTab">;

const loadInitialUiState = (): PersistedUiState => {
  const saved = storage.get<PersistedUiState>(STORAGE_KEYS.UI_STATE);
  return (
    saved ?? {
      selectedDate: today(),
      activeTab: "endOfDay",
    }
  );
};

export const useUiStore = create<UiState>((set, get) => {
  const initial = loadInitialUiState();

  const persist = () => {
    const snapshot: PersistedUiState = {
      selectedDate: get().selectedDate,
      activeTab: get().activeTab,
    };
    storage.set(STORAGE_KEYS.UI_STATE, snapshot);
  };

  return {
    selectedDate: initial.selectedDate,
    activeTab: initial.activeTab,

    setSelectedDate: (date) => {
      set({ selectedDate: date });
      persist();
    },

    setActiveTab: (tab) => {
      set({ activeTab: tab });
      persist();
    },
  };
});