import { create } from "zustand";
import { storage } from "../persist/storage";
import { STORAGE_KEYS } from "../persist/storageKeys";
import type { DailyEntry, DateKey } from "../../domain/daily/daily.model";
import { makeEmptyDailyEntry } from "../../domain/daily/daily.model";

export type SyncStatus = "idle" | "saving" | "saved" | "error";

type DailyState = {
  byDate: Record<DateKey, DailyEntry>;
  syncByDate: Record<DateKey, SyncStatus>;

  getEntry: (date: DateKey) => DailyEntry;

  // Prepaid
  setPrepaidInput: (date: DateKey, value: number | null) => void;

  // End of Day (current)
  setEndOfDayInput1: (date: DateKey, value: number | null) => void;
  setEndOfDayInput2: (date: DateKey, value: number | null) => void;

  // End of Day - Propane POS
  setPropaneExchange: (date: DateKey, value: number | null) => void;
  setPropaneNew: (date: DateKey, value: number | null) => void;

  // Propane Counts
  setFillOpening: (date: DateKey, value: number | null) => void;
  setFillDelivery: (date: DateKey, value: number | null) => void;
  setFillClosing: (date: DateKey, value: number | null) => void;

  setTotalOpening: (date: DateKey, value: number | null) => void;
  setTotalDelivery: (date: DateKey, value: number | null) => void;
  setTotalClosing: (date: DateKey, value: number | null) => void;

  getSyncStatus: (date: DateKey) => SyncStatus;
  clearDate: (date: DateKey) => void;
};

type PersistedDailyState = Pick<DailyState, "byDate">;

const SAVE_DEBOUNCE_MS = 400;
const saveTimers: Record<string, number | undefined> = {};

const loadInitialDailyState = (): PersistedDailyState => {
  const saved = storage.get<PersistedDailyState>(STORAGE_KEYS.DAILY_STATE);
  return saved ?? { byDate: {} };
};

export const useDailyStore = create<DailyState>((set, get) => {
  const initial = loadInitialDailyState();

  const persistNow = () => {
    const snapshot: PersistedDailyState = { byDate: get().byDate };
    storage.set(STORAGE_KEYS.DAILY_STATE, snapshot);
  };

  const schedulePersist = (date: DateKey) => {
    set((state) => ({
      syncByDate: { ...state.syncByDate, [date]: "saving" },
    }));

    const existing = saveTimers[date];
    if (existing) window.clearTimeout(existing);

    saveTimers[date] = window.setTimeout(() => {
      try {
        persistNow();

        set((state) => ({
          syncByDate: { ...state.syncByDate, [date]: "saved" },
        }));
      } catch {
        set((state) => ({
          syncByDate: { ...state.syncByDate, [date]: "error" },
        }));
      }
    }, SAVE_DEBOUNCE_MS);
  };

 const ensureEntry = (date: DateKey): DailyEntry => {
  const existing = get().byDate[date];

  // اگر قبلاً چیزی برای این تاریخ نداشتیم
  if (!existing) {
    const created = makeEmptyDailyEntry();
    set((state) => ({
      byDate: { ...state.byDate, [date]: created },
      syncByDate: { ...state.syncByDate, [date]: "idle" },
    }));
    return created;
  }

  // اگر entry قدیمی بود و بعضی فیلدهای جدید (مثل propane) را نداشت،
  // با empty model merge می‌کنیم تا هیچ چیز undefined نشود
  const normalized: DailyEntry = {
    ...makeEmptyDailyEntry(),
    ...existing,
  };

  // اگر normalized با existing فرق داشت، ذخیره‌اش کن
  const changed = JSON.stringify(existing) !== JSON.stringify(normalized);

  if (changed) {
    set((state) => ({
      byDate: { ...state.byDate, [date]: normalized },
    }));
  }

  return normalized;
};

  const patchEntry = (date: DateKey, patch: Partial<DailyEntry>) => {
    const current = ensureEntry(date);
    const next: DailyEntry = { ...current, ...patch };

    set((state) => ({
      byDate: { ...state.byDate, [date]: next },
    }));

    schedulePersist(date);
  };

  return {
    byDate: initial.byDate,
    syncByDate: {},

    getEntry: (date) => ensureEntry(date),

    // Prepaid
    setPrepaidInput: (date, value) => patchEntry(date, { prepaidInput: value }),

    // End of Day (current)
    setEndOfDayInput1: (date, value) => patchEntry(date, { endOfDayInput1: value }),
    setEndOfDayInput2: (date, value) => patchEntry(date, { endOfDayInput2: value }),

    // End of Day - Propane POS
    setPropaneExchange: (date, value) => patchEntry(date, { propaneExchange: value }),
    setPropaneNew: (date, value) => patchEntry(date, { propaneNew: value }),

    // Propane Counts
    setFillOpening: (date, value) => patchEntry(date, { fillOpening: value }),
    setFillDelivery: (date, value) => patchEntry(date, { fillDelivery: value }),
    setFillClosing: (date, value) => patchEntry(date, { fillClosing: value }),

    setTotalOpening: (date, value) => patchEntry(date, { totalOpening: value }),
    setTotalDelivery: (date, value) => patchEntry(date, { totalDelivery: value }),
    setTotalClosing: (date, value) => patchEntry(date, { totalClosing: value }),

    getSyncStatus: (date) => get().syncByDate[date] ?? "idle",

    clearDate: (date) => {
      const t = saveTimers[date];
      if (t) window.clearTimeout(t);
      delete saveTimers[date];

      set((state) => {
        const nextByDate = { ...state.byDate };
        const nextSync = { ...state.syncByDate };
        delete nextByDate[date];
        delete nextSync[date];
        return { byDate: nextByDate, syncByDate: nextSync };
      });

      persistNow();
    },
  };
});