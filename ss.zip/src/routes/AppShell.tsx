import GasStationLayout from "../layouts/GasStationLayout.tsx";
import EndOfDayPage from "../features/summary/pages/EndOfDayPage";
import PrepaidPage from "../features/prepaid/pages/PrepaidPage";
import { useUiStore } from "../store/ui/ui.store";
import PropanePage from "../features/propane/pages/PropanePage.tsx";

const AppShell = () => {
  const date = useUiStore((s) => s.selectedDate);

   return (
    <GasStationLayout
      endOfDay={<EndOfDayPage date={date} />}
      prepaid={<PrepaidPage date={date} />}
      propane={<PropanePage date={date} />}
    />
  );
};

export default AppShell;