export type DateKey = string; // "YYYY-MM-DD"

export type DailyEntry = {
  // Prepaid
  prepaidInput: number | null;

  // End of Day (current)
  endOfDayInput1: number | null;
  endOfDayInput2: number | null;

  // End of Day - Propane POS
  propaneExchange: number | null;
  propaneNew: number | null;

  // Propane Counts
  fillOpening: number | null;
  fillDelivery: number | null; // optional
  fillClosing: number | null;

  totalOpening: number | null;
  totalDelivery: number | null; // optional
  totalClosing: number | null;
};

export const makeEmptyDailyEntry = (): DailyEntry => ({
  // Prepaid
  prepaidInput: null,

  // End of Day (current)
  endOfDayInput1: null,
  endOfDayInput2: null,

  // End of Day - Propane POS
  propaneExchange: null,
  propaneNew: null,

  // Propane Counts
  fillOpening: null,
  fillDelivery: null,
  fillClosing: null,

  totalOpening: null,
  totalDelivery: null,
  totalClosing: null,
});